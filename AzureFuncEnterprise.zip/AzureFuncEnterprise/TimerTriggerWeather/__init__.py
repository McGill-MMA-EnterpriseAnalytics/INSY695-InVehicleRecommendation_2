import datetime
import logging

import azure.functions as func

import requests
import pandas as pd
import numpy as np
import psycopg2
from sqlalchemy import create_engine
import datetime
from datetime import date, timedelta
import json
from sqlalchemy import MetaData


def main(mytimer: func.TimerRequest) -> None:
    utc_timestamp = datetime.datetime.utcnow().replace(
        tzinfo=datetime.timezone.utc).isoformat()

    if mytimer.past_due:
        logging.info('The timer is past due!')

    logging.info('Python timer trigger function ran at %s', utc_timestamp)

    ### Weather API ###  "1 0 4 * * *"

    def weekly_weather():
    
        response = requests.get("https://api.openweathermap.org/data/2.5/onecall?lat=43.678524&lon=-79.629129&exclude=current,minutely,hourly,&appid=598c969b4cff1c8f2a3e04dc6363e55c")
        
        x = response.json()

        def getrs(obj):
            Forecast = []
            Forecast = pd.DataFrame([],columns = ["Date","Snow (cm)","Rain (mm)", "Temp_Min", "Temp_Max"])
            q = len(obj["daily"])
            for i in range(q):
                if obj["daily"][i]["weather"][0]['description'] == 'rain and snow':
                    r = obj["daily"][i]["rain"]
                    s = obj["daily"][i]["snow"]
                    dt = obj["daily"][i]["dt"]
                    t_min = obj["daily"][i]["temp"]['min']
                    t_max = obj["daily"][i]["temp"]['max']
                    temp_df = [dt,s,r,t_min,t_max]
                    a_series = pd.Series(temp_df,index = Forecast.columns)
                    Forecast = Forecast.append(a_series, ignore_index=True)
                elif obj["daily"][i]["weather"][0]['main'] == 'Rain':
                    r = obj["daily"][i]["rain"]
                    s = 0
                    dt = obj["daily"][i]["dt"]
                    t_min = obj["daily"][i]["temp"]['min']
                    t_max = obj["daily"][i]["temp"]['max']
                    temp_df = [dt,s,r,t_min,t_max]
                    a_series = pd.Series(temp_df,index = Forecast.columns)
                    Forecast = Forecast.append(a_series, ignore_index=True)
                elif obj["daily"][i]["weather"][0]['main'] == 'Snow':
                    r = 0
                    s = obj["daily"][i]["snow"]
                    dt = obj["daily"][i]["dt"]
                    t_min = obj["daily"][i]["temp"]['min']
                    t_max = obj["daily"][i]["temp"]['max']
                    temp_df = [dt,s,r,t_min,t_max]
                    a_series = pd.Series(temp_df,index = Forecast.columns)
                    Forecast = Forecast.append(a_series, ignore_index=True)
                else:
                    r = 0
                    s = 0
                    dt = obj["daily"][i]["dt"]
                    t_min = obj["daily"][i]["temp"]['min']
                    t_max = obj["daily"][i]["temp"]['max']
                    temp_df = [dt,s,r,t_min,t_max]
                    a_series = pd.Series(temp_df,index = Forecast.columns)
                    Forecast = Forecast.append(a_series, ignore_index=True)
            Forecast.Date = Forecast.apply(lambda Forecast: datetime.datetime.fromtimestamp(Forecast.Date), axis=1)
            
            return Forecast
        getrs(x)
        
        # On some days there is rain and snow so that might have to be adjusted
        
        data=getrs(x)
        
        data['Snow'] = np.where(data['Snow (cm)']>=0.5, 1, 0)
        data['Snowstorm'] = np.where(data['Snow (cm)']>=0.8, 1, 0)
        data['Rainday'] = np.where(data['Rain (mm)']>=0.5, 1, 0)
        
        data.rename(columns = {'Date':'date', 'Snow (cm)':'snow_cm', 'Rain (mm)':'rain_mm',
                            'Snow':'is_snow', 'Snowstorm':'is_snowstorm', 'Rainday':'is_rainday'}, inplace = True)
        
        data['updated_at'] = datetime.datetime.now()
        
        # Exporting weather dataset to PostgreSQL
        
        engine = create_engine('postgresql://group7:Enterprise7@enterprisedb.postgres.database.azure.com:5432/postgres')
        meta = MetaData(engine)
        meta.reflect(engine)
        table = meta.tables['weather']
        del_st = table.delete()
        conn = engine.connect()
        res = conn.execute(del_st)
        data.to_sql('weather', engine, if_exists='append')


    # Function call
    weekly_weather()
